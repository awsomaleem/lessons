import math


# PROBLEM 1
def return_17(my_parameter):
	return my_parameter + 3

# Change None!
# call this function with the correct parameter so that the function returns 17
problem1 = None

# PROBLEM 2
def print_quote(my_parameter):
	quote = "So no one told you life"
	return (quote + my_parameter)

# Change None!
# pass in the parameter so the function returns out " So no one told you life was gonna be this way"
friends = None

# PROBLEM 3
def return_17_2(my_number):
	return my_number + 3.0

# Change None!
# pass in the correct parameter so that the function returns 17
problem3_parameter = None
problem3 = return_17_2(problem3_parameter)


# PROBLEM 4
def quadratic_formula(a, b, c):
	# write a function here where given the parameters: a,b,c, the function RETURNS one of the
	# two roots of the quadratic formula as a pair
	# hint: https://en.wikipedia.org/wiki/Quadratic_formula#/media/File:Quadratic_formula.svg
	# Change None
	return None