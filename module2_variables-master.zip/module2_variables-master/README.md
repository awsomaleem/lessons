# module2_variables

~~~
1). Clone the repository
2). Answer the questions in assignment.py and save your work
3). Run the test cases in test_assignment.py by running ./test_assignment.py. You can now see which questions are correct which ones are incorrect.
~~~